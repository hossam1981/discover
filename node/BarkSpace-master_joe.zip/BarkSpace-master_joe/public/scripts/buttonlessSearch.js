// // we need a key down 
// // ascii 
// //add event listenter to key down 
// //send the result
// // to the input for search 


// $("document").ready(function() {
//   console.log("Im here!");
  
//  document.addEventListener("keydown", keyDownTextField, false);

// function keyDownTextField(e) {
// var keyCode = e.keyCode;
//   if(keyCode==13) {
//   alert("You hit the enter key.");
//   } else {
//   alert("Oh no you didn't.");
//   }
    
//     // ascii = 13
//     // but the result...
//   })
    
// })